"""Internal HTTP client for MudraID's control-plane endpoints.

This module is the *single* place inside the SDK that talks to MudraID
itself (as opposed to the platforms the agent calls). Both
:mod:`mudraid._token_manager` and :mod:`mudraid._platform_resolver`
route their HTTP traffic through here so:

  - base-URL joining is consistent
  - status-code → exception mapping is consistent (resists drift)
  - timeouts have one default
  - the underlying ``requests.Session`` is reused (connection pooling)
  - a future addition of correlation IDs / metrics / TLS pinning
    has exactly one site to touch.
"""

from __future__ import annotations

import logging
from typing import Any

import requests

from mudraid._env import SdkConfig
from mudraid.exceptions import (
    MudraIDAuthError,
    MudraIDNetworkError,
    MudraIDRateLimitedError,
    MudraIDRevokedError,
)

_logger = logging.getLogger("mudraid.http")

_DEFAULT_TIMEOUT_SEC = 10.0


def _retry_after_seconds(response: requests.Response) -> int | None:
    """Whole seconds from a ``Retry-After`` header, or ``None``.

    ``None`` means "the server did not tell us", never a guessed default: a
    caller must be able to distinguish a delay it was given from one it made
    up. Only the delta-seconds form is read — MudraID sends that — and an
    HTTP-date, a negative value or anything unparseable is treated as absent
    rather than coerced into a number that would be wrong.
    """
    raw = (response.headers.get("Retry-After") or "").strip()
    if not raw:
        return None
    try:
        seconds = int(raw)
    except ValueError:
        return None
    return seconds if seconds >= 0 else None


def _error_code(response: requests.Response) -> str | None:
    """The server's own machine-readable ``error_code``, when it sent one.

    Only identity-service's application-level refusals carry this field. A
    limiter at the edge answers with its own body shape and no ``error_code``,
    which is precisely the signal we want: absence means "not attributable",
    not "attributable to the default".
    """
    try:
        body = response.json()
    except ValueError:
        return None
    if isinstance(body, dict):
        code = body.get("error_code")
        if isinstance(code, str) and code:
            return code
    return None


# identity-service's per-api_key_id limiter, shared by /auth/token,
# /auth/verify and the bootstrap read (see its TokenRateLimiter).
_SHARED_KEY_BUDGET_CODE = "RATE_LIMITED"
# identity-service's per-ACCOUNT plan ceiling / abuse block (BM-E9-S1). A
# different limit with a different remedy: waiting may never clear it.
_ACCOUNT_FAIR_USE_CODE = "FAIR_USE_EXCEEDED"


def _rate_limit_attribution(response: requests.Response) -> str:
    """Which limiter refused, stated only when the body itself identifies it.

    THE DEFAULT IS "WE DO NOT KNOW", and that is the correction this function
    exists to make. An unattributed 429 gets a message that says so rather than
    one that names the per-key budget on no evidence.
    """
    code = _error_code(response)
    if code == _SHARED_KEY_BUDGET_CODE:
        return (
            " This one is the per-api_key_id budget, shared across token, "
            "verify and platform-bootstrap calls for this key — spending it on "
            "any of them spends it for all three."
        )
    if code == _ACCOUNT_FAIR_USE_CODE:
        return (
            " This one is the ACCOUNT's fair-use ceiling, not a per-key budget. "
            "Slowing this agent down may not clear it: the limit belongs to the "
            "whole account, so check the plan in the MudraID portal."
        )
    return (
        " MudraID limits these calls at more than one layer and this response "
        "did not say which one refused — it may be the per-api_key_id budget, "
        "the account's fair-use ceiling, or a gateway limit keyed by caller "
        "source and shared with everything else behind the same address. "
        "Slowing down is the first move either way."
    )


def _safe_detail(response: requests.Response) -> str | None:
    """Best-effort extraction of the server's `detail` field.

    Errors and non-JSON bodies are swallowed — we never let detail
    extraction itself raise. Returns ``None`` when no usable detail
    is available; callers should fall back to their own default
    message.
    """
    try:
        body = response.json()
    except ValueError:
        return None
    if isinstance(body, dict):
        detail = body.get("detail") or body.get("message")
        if isinstance(detail, str) and detail:
            return detail
    return None


class MudraIDHttpClient:
    """Thin HTTP client for MudraID's own API surface.

    Not for use against the platforms the agent calls — those go
    through ``requests`` directly (with the Bearer JWT attached) in
    :mod:`mudraid._agent`.
    """

    def __init__(self, config: SdkConfig, timeout: float = _DEFAULT_TIMEOUT_SEC) -> None:
        self._config = config
        self._timeout = timeout
        # A Session lets us reuse the TCP connection across the
        # bootstrap call and the per-platform token mints — meaningful
        # latency saving on agents that talk to multiple platforms.
        self._session = requests.Session()

    @property
    def base_url(self) -> str:
        return self._config.base_url

    @property
    def api_key_id(self) -> str:
        return self._config.api_key_id

    @property
    def secret(self) -> str:
        # Module-internal. Never logged; never exposed via Agent.
        return self._config.secret

    def post_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        """POST a JSON body to ``base_url + path`` and return the parsed response.

        Maps responses to SDK exceptions:

          * 2xx with valid JSON → parsed dict returned.
          * 401 → :class:`MudraIDAuthError`.
          * 403 → :class:`MudraIDRevokedError`, message taken from the
            server's ``detail`` when present.
          * Network failure / timeout / non-JSON / other non-2xx →
            :class:`MudraIDNetworkError`.

        The request body is *not* echoed into any exception message —
        it contains the agent's plaintext secret.
        """
        url = f"{self._config.base_url}{path}"
        # `path` is logged; `body` is NOT. The MudraID request body
        # contains the agent's plaintext secret — it must never appear
        # in logs, exception messages, or any other diagnostic output.
        _logger.debug("POST %s", path)
        try:
            response = self._session.post(url, json=body, timeout=self._timeout)
        except requests.RequestException as exc:
            # Chain the underlying transport error for debuggability,
            # but keep the surfaced message generic so it never echoes
            # the request body.
            raise MudraIDNetworkError(
                f"could not reach MudraID at {self._config.base_url}"
            ) from exc

        _logger.debug("MudraID returned %d for %s", response.status_code, path)

        if response.status_code == 401:
            raise MudraIDAuthError("invalid credentials")
        if response.status_code == 403:
            detail = _safe_detail(response) or (
                "agent not authorized for this MudraID call; check platform "
                "grants in the MudraID portal"
            )
            raise MudraIDRevokedError(detail)
        if response.status_code == 429:
            # The credentials were never examined, so this is emphatically NOT
            # an auth failure — "unexpected status 429" invited exactly that
            # misreading, which is why this branch exists.
            #
            # BUT THE SDK CANNOT KNOW WHICH LIMITER SPOKE. At least three sit on
            # these paths and only two of them are the same thing:
            #
            #   * identity-service's per-api_key_id budget    -> RATE_LIMITED
            #   * identity-service's per-ACCOUNT fair-use ceiling
            #                                                 -> FAIR_USE_EXCEEDED
            #   * Kong's service-level rate-limiting plugin on the whole
            #     identity-service block, keyed by caller source rather than by
            #     key, which answers with its own body and no error_code
            #
            # So the message leads with what is certainly true and attributes a
            # cause ONLY when the body says so itself. Naming the per-key budget
            # unconditionally would send a reader to throttle one agent when the
            # real limit was their account plan or a shared egress IP — a
            # confident wrong answer, which is worse than the vague one it
            # replaced.
            retry_after = _retry_after_seconds(response)
            wait = (
                f" Retry after {retry_after}s."
                if retry_after is not None
                else " The server sent no Retry-After, so the length is unknown."
            )
            raise MudraIDRateLimitedError(
                f"MudraID rate-limited this request to {path}.{wait}"
                f"{_rate_limit_attribution(response)}",
                retry_after_seconds=retry_after,
            )
        if response.status_code == 404:
            # THE ONE THAT COST SOMEONE TWO DAYS. A 404 from the control plane
            # is almost never "this resource does not exist" — the SDK calls
            # two fixed, always-present paths. It means the request reached
            # something that is not MudraID's control plane for this agent:
            # the wrong base_url, or an edge that does not route this path.
            #
            # The SDK KNOWS the base_url and has always logged it at DEBUG. The
            # message just never said it, so the one fact that identifies the
            # cause was one log level away from a reader who had no reason to
            # think configuration was involved.
            raise MudraIDNetworkError(
                f"MudraID returned 404 for {path} at {self._config.base_url}. "
                "That path exists on every MudraID deployment, so this usually "
                "means MUDRAID_BASE_URL points somewhere that is not MudraID's "
                "control plane for this agent — check it before the credentials. "
                "An agent also exists in exactly one environment: credentials "
                "issued by one are unknown to another."
            )
        if not 200 <= response.status_code < 300:
            raise MudraIDNetworkError(
                f"unexpected status {response.status_code} from MudraID "
                f"for {path} at {self._config.base_url}"
            )

        try:
            return response.json()
        except ValueError as exc:
            raise MudraIDNetworkError("MudraID returned a non-JSON response") from exc

    def close(self) -> None:
        self._session.close()
